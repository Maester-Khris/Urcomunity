<footer>
      <div class="footy-sec mn no-margin">
            <div class="container">
                  <ul>
                        <li><a href="/zones-voir" title="">Zones</a></li>
                        <li><a href="/membres-voir" title="">Membres</a></li>
                        <li><a href="#" title="">Regles du groupe</a></li>
                        <li><a href="#" title="">A propos de la communauté</a></li>
                        <li><a href="/contact" title="">Contacter un delegué</a></li>
                  </ul>
                  <!-- <p><img src="images/copy-icon2.png" alt="">Copyright 2018</p>
                  <img  src="images/logo2.png" alt=""> -->
                  <p><img src="{{asset('images/cp.png')}}" alt="">Copyright 2022</p>
               <img class="fl-rgt" src="{{asset('images/01_Icon-Community@2x.png')}}" alt="" style="width:75px!important; height:45px!important;margin-top:20px">
            </div>
      </div>
</footer>
